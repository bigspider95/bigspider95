In this project   The is a side view city created by me....And One Player I made of myself... And One
Crawler zombie... What's going on when game plays... At the begginning of the scene hide black sprite
crawler moves left and right... player can move left and right using default keys and jump I also implemented
attacking using x button... there isn't health or damage but it's a start



it's made by my Dylan James Wiley: Email: tomascolt12@gmail.com You can find me on
Deviant art: https://www.deviantart.com/xxdowntoearthfooxx
or twitter:  Username @DylanWi00569572
Other backup Email: tomascolt14@yahoo.com